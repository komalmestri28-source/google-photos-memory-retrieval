import { route, send, readJson, fail } from '../lib/http.js';
import { askJson } from '../lib/llm.js';
import { PARSE_SYSTEM } from '../lib/prompts.js';
import { sanitizeClues } from '../lib/vocab.js';
import { mockParse } from '../lib/mock.js';

const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);

export default route(['POST'], async (req, res) => {
  const body = await readJson(req);
  const memory = String(body.memory || '').replace(/\s+/g, ' ').trim().slice(0, 500);
  if (memory.length < 4) throw fail(400, 'Write a few words about what you remember.');
  const today = isDate(body.today) ? body.today : new Date().toISOString().slice(0, 10);
  const range = isDate(body.earliest) && isDate(body.latest) ? `The library holds photos from ${body.earliest} to ${body.latest}.` : '';

  const { json, provider, model } = await askJson({
    system: PARSE_SYSTEM,
    parts: [{ text: `Today is ${today}. ${range}\n\nWhat the person remembers:\n<memory>\n${memory.replace(/<\/?memory>/gi, ' ')}\n</memory>` }],
    maxTokens: 3000,
    mock: () => mockParse(memory, today)
  });
  send(res, 200, { clues: sanitizeClues(json), provider, model });
});
