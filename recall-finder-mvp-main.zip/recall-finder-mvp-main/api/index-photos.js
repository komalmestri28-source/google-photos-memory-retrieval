import { route, send, readJson, fail } from '../lib/http.js';
import { askJson } from '../lib/llm.js';
import { INDEX_SYSTEM } from '../lib/prompts.js';
import { sanitizePhoto } from '../lib/vocab.js';
import { mockIndex } from '../lib/mock.js';

const MAX_PHOTOS = 5;
const MAX_B64 = 600_000; // about 450 kB per shrunken image

export default route(['POST'], async (req, res) => {
  const body = await readJson(req);
  const photos = Array.isArray(body.photos) ? body.photos : [];
  if (!photos.length) throw fail(400, 'Send {photos:[{id, image}]}.');
  if (photos.length > MAX_PHOTOS) throw fail(400, `Send at most ${MAX_PHOTOS} photos per request.`);

  const clean = photos.map((p) => ({ id: String(p.id || '').replace(/[^\w-]/g, '').slice(0, 40), image: String(p.image || '').replace(/^data:image\/\w+;base64,/, '') }));
  for (const p of clean) {
    if (!p.id || !p.image) throw fail(400, 'Each photo needs an id and an image.');
    if (p.image.length > MAX_B64 || !/^[A-Za-z0-9+/=]+$/.test(p.image)) throw fail(400, 'An image is too large or not valid. Images must be shrunk before sending.');
  }

  const parts = [];
  for (const p of clean) { parts.push({ text: `Photo id: ${p.id}` }); parts.push({ image: p.image }); }
  parts.push({ text: `Describe these ${clean.length} photos.` });

  const { json, provider, model } = await askJson({ system: INDEX_SYSTEM, parts, maxTokens: 8000, mock: () => mockIndex(clean.map((p) => p.id)) });
  const returned = Array.isArray(json) ? json : Array.isArray(json?.photos) ? json.photos : [];
  const byId = new Map(returned.filter((r) => r && r.id != null).map((r) => [String(r.id), r]));
  // If the model dropped the ids but kept the order and count, fall back to position.
  const positional = byId.size === 0 && returned.length === clean.length;

  const out = clean.map((p, i) => {
    const raw = byId.get(p.id) || (positional ? returned[i] : null);
    return raw ? { ...sanitizePhoto({ ...raw, id: p.id }), described: true } : { id: p.id, described: false };
  });
  send(res, 200, { photos: out, provider, model });
});
