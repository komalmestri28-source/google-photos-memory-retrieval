// Matching logic for the clue finder. Pure functions: no DOM, no network, no model.
// Everything here runs in the browser, so narrowing is instant and costs nothing.

export const DAY = 86400000;
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const PEOPLE_ORDER = ['none', 'one', 'two', 'group'];

// ---- reading facts from a file name ----
export function detectSource(name, hasCameraExif, modelSaysScreenshot) {
  const n = String(name || '');
  if (/screen[\s_-]?shot|scrnshot|screen[\s_-]?record/i.test(n)) return 'screenshot';
  if (/(^|[-_ ])WA\d{3,}|whatsapp/i.test(n)) return 'whatsapp';
  if (modelSaysScreenshot) return 'screenshot';
  if (hasCameraExif) return 'camera';
  if (/^(IMG|PXL|DSC|DSCN|DSCF|MVIMG|P)_?\d{3,}|^\d{8}_\d{6}/i.test(n)) return 'camera';
  return 'saved';
}

export function dateFromName(name) {
  const m = String(name || '').match(/(20\d{2})[-_.]?(0[1-9]|1[0-2])[-_.]?(0[1-9]|[12]\d|3[01])/);
  if (!m) return null;
  const iso = `${m[1]}-${m[2]}-${m[3]}`;
  const t = Date.parse(iso);
  return Number.isNaN(t) || t > Date.now() + DAY ? null : iso;
}

// ---- scoring one clue against one photo: 1 fits, 0.5 nearly fits, 0 does not ----
const hay = (p) => `${p.caption || ''} ${(p.tags || []).join(' ')} ${p.text || ''}`.toLowerCase();
const hasTerm = (h, term) => new RegExp(`(^|[^a-z0-9])${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'i').test(h);

export function clueScore(c, p) {
  switch (c.type) {
    case 'when': {
      if (!p.date) return 0.5; // unknown date: cannot rule it out
      const t = Date.parse(p.date);
      if (t >= c.from && t <= c.to) return 1;
      const slack = Math.max(45 * DAY, 0.3 * (c.to - c.from)); // memory for time is loose
      return t >= c.from - slack && t <= c.to + slack ? 0.5 : 0;
    }
    case 'source': return p.source === c.value ? 1 : 0;
    case 'kind': return c.values.includes(p.kind) ? 1 : 0;
    case 'setting': return p.setting === c.value ? 1 : p.setting === 'unknown' ? 0.5 : 0;
    case 'hastext': return (!!p.text) === c.value ? 1 : 0;
    case 'people': {
      if (p.people === c.value) return 1;
      const a = PEOPLE_ORDER.indexOf(p.people), b = PEOPLE_ORDER.indexOf(c.value);
      return a > 0 && b > 0 && Math.abs(a - b) === 1 ? 0.5 : 0; // "two" vs "a group" is an easy slip
    }
    case 'word': {
      const w = c.value.toLowerCase();
      if ((p.text || '').toLowerCase().includes(w)) return 1;
      return hay(p).includes(w) ? 0.5 : 0;
    }
    case 'thing': { const h = hay(p); return c.terms.some((t) => hasTerm(h, t)) ? 1 : 0; }
    default: return 1;
  }
}

// Ranks every photo. Nothing is ever filtered out: a photo that misses one clue drops a tier
// instead of disappearing, so one wrong memory cannot produce an empty result.
export function rank(photos, clues, dismissed = new Set()) {
  const rows = [];
  for (const p of photos) {
    if (dismissed.has(p.id)) continue;
    const misses = []; let nears = 0;
    clues.forEach((c, i) => { const s = clueScore(c, p); if (s === 0) misses.push(i); else if (s < 1) nears++; });
    rows.push({ p, misses, nears, tier: misses.length });
  }
  rows.sort((a, b) => a.tier - b.tier || a.nears - b.nears || (Date.parse(b.p.date || 0) || 0) - (Date.parse(a.p.date || 0) || 0));
  return rows;
}

// ---- choosing the next question: the one whose answer splits the remaining pile most evenly ----
function entropy(counts, total) {
  let hh = 0;
  for (const n of counts) if (n > 0) { const q = n / total; hh -= q * Math.log2(q); }
  return hh;
}

function whenBuckets(pile) {
  const dated = pile.filter((p) => p.date);
  if (dated.length < pile.length * 0.6) return null;
  const years = new Map();
  for (const p of dated) { const y = p.date.slice(0, 4); years.set(y, (years.get(y) || 0) + 1); }
  if (years.size > 1) {
    return [...years.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([y, n]) => ({
      n, label: y, clue: { type: 'when', from: Date.parse(`${y}-01-01`), to: Date.parse(`${y}-12-31`) + DAY - 1, label: `in ${y}` }
    }));
  }
  const y = [...years.keys()][0];
  const quarters = [0, 0, 0, 0];
  for (const p of dated) quarters[Math.floor((Number(p.date.slice(5, 7)) - 1) / 3)]++;
  return quarters.map((n, q) => {
    const from = new Date(Date.UTC(Number(y), q * 3, 1)).getTime(), to = new Date(Date.UTC(Number(y), q * 3 + 3, 1)).getTime() - 1;
    const label = `${MONTHS[q * 3]} to ${MONTHS[q * 3 + 2]} ${y}`;
    return { n, label, clue: { type: 'when', from, to, label } };
  }).filter((b) => b.n > 0);
}

export function nextQuestion(pile, clues, skipped, vocab) {
  if (pile.length <= 12) return null;
  const has = (type) => clues.some((c) => c.type === type);
  const dist = (fn) => { const m = new Map(); for (const p of pile) { const v = fn(p); if (v != null) m.set(v, (m.get(v) || 0) + 1); } return m; };
  const fromDist = (m, labels, mk) => [...m.entries()].map(([v, n]) => ({ n, label: labels[v] || v, clue: mk(v) }));
  const candidates = [];

  if (!has('source') && !skipped.has('source')) candidates.push({ facet: 'source', title: 'How did it get onto your phone?',
    options: fromDist(dist((p) => p.source), vocab.source, (v) => ({ type: 'source', value: v, label: vocab.source[v].toLowerCase() })) });
  if (!has('kind') && !skipped.has('kind')) candidates.push({ facet: 'kind', title: 'What was it a photo of?',
    options: fromDist(dist((p) => p.kind), vocab.kind, (v) => ({ type: 'kind', values: [v], label: vocab.kind[v].toLowerCase() })) });
  if (!has('when') && !skipped.has('when')) { const b = whenBuckets(pile); if (b) candidates.push({ facet: 'when', title: 'Roughly when was it?', options: b, ordered: true }); }
  if (!has('people') && !skipped.has('people')) candidates.push({ facet: 'people', title: 'Were there people in it?',
    options: fromDist(dist((p) => p.people), vocab.people, (v) => ({ type: 'people', value: v, label: vocab.people[v].toLowerCase() })) });
  if (!has('word') && !has('hastext') && !skipped.has('hastext')) candidates.push({ facet: 'hastext', title: 'Was there any writing in it?',
    options: fromDist(dist((p) => (p.text ? 'yes' : 'no')), { yes: 'Yes, it had writing', no: 'No writing' }, (v) => ({ type: 'hastext', value: v === 'yes', label: v === 'yes' ? 'had writing in it' : 'no writing in it' })) });
  if (!has('setting') && !skipped.has('setting')) candidates.push({ facet: 'setting', title: 'Was it indoors or outdoors?',
    options: fromDist(dist((p) => (p.setting === 'indoor' || p.setting === 'outdoor' ? p.setting : null)), vocab.setting, (v) => ({ type: 'setting', value: v, label: vocab.setting[v].toLowerCase() })) });

  let best = null;
  for (const c of candidates) {
    const opts = c.options.filter((o) => o.n > 0);
    const total = opts.reduce((s, o) => s + o.n, 0);
    if (opts.length < 2 || total < pile.length * 0.5) continue;
    if (Math.max(...opts.map((o) => o.n)) > total * 0.85) continue; // an answer that barely narrows is not worth asking
    const score = entropy(opts.map((o) => o.n), total);
    if (!best || score > best.score) best = { ...c, options: opts, score };
  }
  if (!best) return null;
  let options = best.ordered ? best.options : [...best.options].sort((a, b) => b.n - a.n);
  if (options.length > 5) options = best.ordered ? options.slice(-5) : options.slice(0, 5);
  return { facet: best.facet, title: best.title, options: options.map(({ label, clue }) => ({ label, clue })) };
}

// ---- practice task: a deliberately vague description of one real photo in the library ----
export function practiceTask(photos, vocab, rnd = Math.random) {
  const pool = photos.filter((p) => p.described && p.caption && (p.tags || []).length >= 2);
  if (!pool.length) return null;
  const p = pool[Math.floor(rnd() * pool.length)];
  const lines = [`It was ${vocab.kind[p.kind].toLowerCase()}.`];
  lines.push(`You think it ${{ camera: 'was taken with the camera', screenshot: 'was a screenshot', whatsapp: 'came on WhatsApp', saved: 'was saved or downloaded from somewhere' }[p.source]}.`);
  if (p.date) {
    const m = Number(p.date.slice(5, 7));
    lines.push(`It was sometime around ${m <= 4 ? 'the start' : m <= 8 ? 'the middle' : 'the end'} of ${p.date.slice(0, 4)}.`);
  }
  lines.push(`You remember something about: ${p.tags.slice(0, 2).join(', ')}.`);
  return { targetId: p.id, lines };
}

export function describeWhen(fromIso, toIso) {
  const f = new Date(fromIso), t = new Date(toIso);
  const fm = `${MONTHS[f.getUTCMonth()]} ${f.getUTCFullYear()}`, tm = `${MONTHS[t.getUTCMonth()]} ${t.getUTCFullYear()}`;
  return fm === tm ? fm : `${fm} to ${tm}`;
}
