// Clue finder MVP: browser side.
// The model is used in exactly two places: describing photos once when a library is added,
// and splitting a sentence of memory into clues. All narrowing happens here, with no model call.

import { DAY, detectSource, dateFromName, rank, nextQuestion, practiceTask, describeWhen } from '/engine.js';

const LOG_KEY = 'rf_attempts_v1';
const MAX_ADD = 150;

const S = {
  status: null, vocab: null,
  photos: [], isSample: false,
  view: 'loading',
  attempt: null, // { clues, skipped, dismissed, startedAt, ... }
  log: []
};

// ---------- helpers ----------
const $ = (sel, el = document) => el.querySelector(sel);
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return el;
}
function fill(el, ...kids) {
  el.replaceChildren(...kids.flat(Infinity).filter((k) => k != null && k !== false).map((k) => (k.nodeType ? k : document.createTextNode(String(k)))));
}
async function api(path, body) {
  const resp = await fetch(path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined);
  let data = null; try { data = await resp.json(); } catch { /* not JSON */ }
  if (!resp.ok) { const e = new Error(data?.error || `Request failed (${resp.status})`); e.status = resp.status; throw e; }
  return data;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const plural = (n, one, many) => `${n.toLocaleString()} ${n === 1 ? one : many}`;
function banner(text, isErr) { const b = $('#banner'); b.hidden = !text; b.className = 'banner' + (isErr ? ' err' : ''); b.textContent = text || ''; }

// ---------- storage: the library lives in IndexedDB, test results in localStorage ----------
const db = {
  open: () => new Promise((res, rej) => { const r = indexedDB.open('recall-finder', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }),
  async get(key) { const d = await this.open(); return new Promise((res, rej) => { const r = d.transaction('kv').objectStore('kv').get(key); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); },
  async set(key, val) { const d = await this.open(); return new Promise((res, rej) => { const t = d.transaction('kv', 'readwrite'); t.objectStore('kv').put(val, key); t.oncomplete = res; t.onerror = () => rej(t.error); }); },
  async del(key) { const d = await this.open(); return new Promise((res, rej) => { const t = d.transaction('kv', 'readwrite'); t.objectStore('kv').delete(key); t.oncomplete = res; t.onerror = () => rej(t.error); }); }
};
async function saveLibrary() { try { await db.set('library', { photos: S.photos, isSample: S.isSample }); } catch { banner('This browser could not save the library. It will work until you close the tab.', true); } }
function saveLog() { try { localStorage.setItem(LOG_KEY, JSON.stringify(S.log)); } catch { /* ignore */ } }

// ---------- adding photos ----------
async function decode(file) {
  try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch { /* fall back */ }
  return new Promise((res, rej) => {
    const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = () => { URL.revokeObjectURL(url); res(img); }; img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('undecodable')); };
    img.src = url;
  });
}
function shrink(src, maxSide, quality) {
  const w = src.width, hh = src.height, k = Math.min(1, maxSide / Math.max(w, hh));
  const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(hh * k));
  const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(src, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', quality);
}
async function readMeta(file) {
  let exif = null;
  try { exif = await window.exifr?.parse(file, ['DateTimeOriginal', 'CreateDate', 'Make', 'Model']); } catch { /* no EXIF */ }
  const d = exif?.DateTimeOriginal || exif?.CreateDate;
  let date = d instanceof Date && !Number.isNaN(d.getTime()) ? new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10) : null;
  let dateFrom = date ? 'the photo itself' : null;
  if (!date) { date = dateFromName(file.name); if (date) dateFrom = 'the file name'; }
  if (!date && file.lastModified) { date = new Date(file.lastModified).toISOString().slice(0, 10); dateFrom = 'the file date'; }
  return { date, dateFrom, camera: !!(exif?.Make || exif?.Model) };
}

async function describeBatch(batch, say) {
  for (let attempt = 1; attempt <= 4; attempt++) {
    try { return await api('/api/index-photos', { photos: batch.map((b) => ({ id: b.rec.id, image: b.analysis })) }); }
    catch (e) {
      if (attempt === 4 || (e.status !== 429 && e.status !== 503 && e.status !== 502)) throw e;
      const wait = e.status === 429 ? 30 : 6;
      for (let s = wait; s > 0; s--) { say(e.status === 429 ? `The model's usage limit was reached. Continuing in ${s} s…` : `The model was busy. Trying again in ${s} s…`); await sleep(1000); }
    }
  }
  return null;
}

async function addPhotos(fileList, ui) {
  let files = [...fileList].filter((f) => f.type.startsWith('image/') || /\.(jpe?g|png|webp|heic|heif)$/i.test(f.name));
  const dropped = files.length > MAX_ADD ? files.length - MAX_ADD : 0;
  files = files.slice(0, MAX_ADD);
  if (!files.length) { ui.say('No photos were selected.', true); return; }
  if (S.isSample) { S.photos = []; S.isSample = false; }
  ui.busy(true);
  let done = 0, unreadable = 0, undescribed = 0, stopped = null;
  const batchSize = S.status.batch || 5;
  let batch = [];

  const flush = async () => {
    if (!batch.length) return;
    const res = await describeBatch(batch, (t) => ui.say(t));
    const byId = new Map(res.photos.map((p) => [p.id, p]));
    for (const b of batch) {
      const d = byId.get(b.rec.id);
      if (d?.described) Object.assign(b.rec, { caption: d.caption, tags: d.tags, text: d.text, kind: d.kind, people: d.people, setting: d.setting, described: true });
      else { Object.assign(b.rec, { caption: '', tags: [], text: '', kind: 'other', people: 'none', setting: 'unknown', described: false }); undescribed++; }
      b.rec.source = detectSource(b.rec.name, b.camera, d?.is_screenshot);
      S.photos.push(b.rec);
    }
    batch = [];
    await saveLibrary();
  };

  for (const file of files) {
    ui.progress(done / files.length);
    ui.say(`Reading photo ${done + 1} of ${files.length}…`);
    try {
      const [meta, bmp] = await Promise.all([readMeta(file), decode(file)]);
      const rec = { id: `p${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`, name: file.name, date: meta.date, dateFrom: meta.dateFrom, thumb: shrink(bmp, 420, 0.7) };
      batch.push({ rec, camera: meta.camera, analysis: shrink(bmp, 768, 0.75) });
      bmp.close?.();
    } catch { unreadable++; }
    done++;
    if (batch.length >= batchSize) { try { await flush(); } catch (e) { stopped = e; break; } }
  }
  if (!stopped) { try { await flush(); } catch (e) { stopped = e; } }
  ui.busy(false); ui.progress(1);

  const notes = [`${plural(S.photos.length, 'photo is', 'photos are')} in the library.`];
  if (unreadable) notes.push(`${plural(unreadable, 'file', 'files')} could not be opened (this browser cannot read that format).`);
  if (undescribed) notes.push(`${plural(undescribed, 'photo was', 'photos were')} not described by the model and can only be found by date and source.`);
  if (dropped) notes.push(`Only the first ${MAX_ADD} were added; add the rest in another go.`);
  if (stopped) notes.push(`Stopped early: ${stopped.message}`);
  S.setupNote = { text: notes.join(' '), err: !!stopped };
  render();
}

// ---------- attempts ----------
function startAttempt({ memory = '', clues = [], practice = null, usedSentence = false, parseFailed = false }) {
  S.attempt = {
    id: Date.now().toString(36), startedAt: Date.now(), memory, usedSentence, parseFailed, practice,
    clues, skipped: new Set(), dismissed: new Set(),
    cluesFromSentence: clues.length, questionsAnswered: 0, questionsSkipped: 0, cluesAddedByHand: 0, cluesRemoved: 0, photosOpened: 0, wrongPicks: 0
  };
  S.view = 'find'; render(); window.scrollTo({ top: 0 });
}

function finishAttempt(outcome, row, position) {
  const a = S.attempt;
  const entry = {
    id: a.id, at: new Date().toISOString(), outcome, seconds: Math.round((Date.now() - a.startedAt) / 1000),
    library: S.photos.length, sample: S.isSample, practice: !!a.practice, memory: a.memory,
    usedSentence: a.usedSentence, parseFailed: a.parseFailed, cluesAtEnd: a.clues.map((c) => c.type), cluesFromSentence: a.cluesFromSentence,
    questionsAnswered: a.questionsAnswered, questionsSkipped: a.questionsSkipped, cluesAddedByHand: a.cluesAddedByHand, cluesRemoved: a.cluesRemoved,
    photosOpened: a.photosOpened, wrongPicks: a.wrongPicks,
    foundTier: row ? row.tier : null, foundPosition: position ?? null, note: ''
  };
  S.log.unshift(entry); saveLog();
  S.attempt = null; S.view = 'done'; render(); window.scrollTo({ top: 0 });
}

function cluesFromParsed(parsed) {
  const v = S.vocab, out = [];
  if (parsed.when) out.push({ type: 'when', from: Date.parse(parsed.when.from), to: Date.parse(parsed.when.to) + DAY - 1, label: parsed.when.label });
  if (parsed.source) out.push({ type: 'source', value: parsed.source, label: v.source[parsed.source].toLowerCase() });
  if (parsed.kind.length) out.push({ type: 'kind', values: parsed.kind, label: parsed.kind.map((k) => v.kind[k].toLowerCase()).join(' or ') });
  if (parsed.people) out.push({ type: 'people', value: parsed.people, label: v.people[parsed.people].toLowerCase() });
  for (const w of parsed.words) out.push({ type: 'word', value: w, label: `“${w}” written in it` });
  for (const t of parsed.things) out.push({ type: 'thing', terms: t.terms, label: t.label });
  return out;
}

const STOP = new Set('the a an of in on at to for from with and or but that this it was were is i my me we our some sometime around about think maybe photo picture pic image had have has took taken sent got when where which there'.split(' '));
function plainWordsClue(memory) {
  const terms = [...new Set(memory.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w)))].slice(0, 8);
  return terms.length ? [{ type: 'thing', terms, label: terms.slice(0, 3).join(', ') }] : [];
}

// ---------- views ----------
function viewSetup() {
  const status = h('div', { class: 'small ' + (S.setupNote?.err ? 'err' : 'muted'), role: 'status', style: 'margin-top:10px;min-height:1.4em' }, S.setupNote?.text || '');
  const prog = h('progress', { max: 1, value: 0, hidden: true });
  const input = h('input', { type: 'file', accept: 'image/*', multiple: true, hidden: true, onchange: (e) => addPhotos(e.target.files, ui) });
  const addBtn = h('button', { class: 'btn', disabled: !S.status.provider, onclick: () => input.click() }, S.photos.length && !S.isSample ? 'Add more photos' : 'Add your own photos');
  const ui = {
    say: (t, err) => { status.textContent = t; status.className = 'small ' + (err ? 'err' : 'muted'); },
    progress: (v) => { prog.hidden = false; prog.value = v; },
    busy: (b) => { addBtn.disabled = b; }
  };
  const who = S.status.provider === 'gemini' ? "Google's Gemini model" : S.status.provider === 'anthropic' ? "Anthropic's Claude model" : 'the model';
  const fileIn = h('input', { type: 'file', accept: 'application/json', hidden: true, onchange: async (e) => {
    try { const d = JSON.parse(await e.target.files[0].text()); if (!Array.isArray(d.photos)) throw 0; S.photos = d.photos; S.isSample = false; await saveLibrary(); S.view = 'home'; render(); }
    catch { ui.say('That file is not a library exported from this prototype.', true); }
  } });

  return [
    h('h1', {}, 'Set up a photo library'),
    h('p', { class: 'muted' }, 'The finder needs a set of photos to search. Use your own to test it on a photo you actually remember.'),
    !S.status.provider && h('div', { class: 'note' }, 'No API key is configured on the server, so new photos cannot be described. A library that is already loaded still works.'),
    h('div', { class: 'card' },
      h('h2', {}, 'Your own photos'),
      h('p', {}, 'Pick 50 to 150 photos. Include the everyday mix: camera shots, screenshots, things people sent you, pictures of bills and documents.'),
      h('p', { class: 'small muted' }, `What happens to them: each photo is shrunk in your browser and the small copy is sent once to ${who} to be described. The descriptions and thumbnails are then kept only in this browser. Leave out anything you would not want a third-party service to see.`),
      h('div', { class: 'row' }, addBtn, input), h('div', { style: 'height:8px' }), prog, status),
    S.hasSample && h('div', { class: 'card' },
      h('h2', {}, 'The sample library'),
      h('p', {}, 'A ready-made set of photos, already described. Good for a quick look or a practice task.'),
      h('button', { class: 'btn ghost', onclick: async () => { await loadSample(); S.view = 'home'; render(); } }, 'Use the sample library')),
    S.photos.length > 0 && h('div', { class: 'card' },
      h('h2', {}, `Current library: ${plural(S.photos.length, 'photo', 'photos')}${S.isSample ? ' (sample)' : ''}`),
      h('div', { class: 'row' },
        h('button', { class: 'btn', onclick: () => { S.view = 'home'; render(); } }, 'Start finding'),
        h('button', { class: 'btn quiet', onclick: () => {
          const a = h('a', { href: URL.createObjectURL(new Blob([JSON.stringify({ exported_at: new Date().toISOString(), photos: S.photos })], { type: 'application/json' })), download: 'sample-library.json' });
          document.body.append(a); a.click(); a.remove();
        } }, 'Export library'),
        h('button', { class: 'btn quiet', onclick: () => fileIn.click() }, 'Import library'), fileIn,
        h('button', { class: 'btn quiet', onclick: async () => { if (!confirm('Remove this library from the browser?')) return; S.photos = []; S.isSample = false; await db.del('library'); render(); } }, 'Remove'))),
    !S.photos.length && h('p', { class: 'small' }, h('button', { class: 'link', onclick: () => fileIn.click() }, 'Import a library file'), fileIn)
  ];
}

function viewHome() {
  const dated = S.photos.filter((p) => p.date).map((p) => p.date).sort();
  const memory = h('textarea', { placeholder: 'e.g. the medicine the doctor gave me, sometime last winter, I think it came on WhatsApp', maxlength: 500 });
  const status = h('div', { class: 'small muted', role: 'status', style: 'min-height:1.4em;margin-top:8px' });
  const go = h('button', { class: 'btn', onclick: async () => {
    const text = memory.value.trim();
    if (text.length < 4) { status.className = 'small err'; status.textContent = 'Write a few words about what you remember, or start with one clue below.'; return; }
    go.disabled = true; status.className = 'small muted'; status.textContent = 'Splitting that into clues…';
    try {
      const r = await api('/api/parse', { memory: text, today: new Date().toISOString().slice(0, 10), earliest: dated[0], latest: dated[dated.length - 1] });
      const clues = cluesFromParsed(r.clues);
      startAttempt({ memory: text, clues: clues.length ? clues : plainWordsClue(text), usedSentence: true, parseFailed: !clues.length });
    } catch { startAttempt({ memory: text, clues: plainWordsClue(text), usedSentence: true, parseFailed: true }); }
  } }, 'Find it');

  return [
    h('h1', {}, 'What do you remember about the photo?'),
    h('p', { class: 'muted' }, 'Anything helps: roughly when, how it reached your phone, what was in it, a word you saw. You do not need the right search words.'),
    h('div', { class: 'card' }, memory, h('div', { style: 'height:10px' }), h('div', { class: 'row' }, go,
      h('button', { class: 'btn ghost', onclick: () => startAttempt({}) }, 'Start with one clue instead')), status),
    h('div', { class: 'card' },
      h('h2', {}, 'No particular photo in mind?'),
      h('p', {}, 'Try a practice task: you get a hazy description of one photo in this library and try to find it.'),
      h('button', { class: 'btn ghost', onclick: () => {
        const t = practiceTask(S.photos, S.vocab);
        if (!t) { banner('This library has no described photos to build a task from.', true); return; }
        startAttempt({ practice: t });
      } }, 'Give me a practice task')),
    h('p', { class: 'small muted' }, `${plural(S.photos.length, 'photo', 'photos')} in this library${S.isSample ? ' (sample)' : ''}. `,
      h('button', { class: 'link', onclick: () => { S.view = 'setup'; render(); } }, 'Change library'), ' ',
      S.log.length > 0 && h('button', { class: 'link', onclick: () => { S.view = 'log'; render(); } }, `Test results (${S.log.length})`))
  ];
}

function clueForm(type, onAdd, onCancel) {
  const v = S.vocab;
  const pick = (label, clue) => h('button', { class: 'opt', onclick: () => onAdd(clue) }, label);
  const textForm = (placeholder, mk) => {
    const inp = h('input', { type: 'text', placeholder, maxlength: 40 });
    const add = () => { const val = inp.value.trim().toLowerCase(); if (val.length >= 2) onAdd(mk(val)); };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
    setTimeout(() => inp.focus(), 0);
    return h('div', { class: 'row' }, h('div', { style: 'flex:1 1 200px' }, inp), h('button', { class: 'btn', onclick: add }, 'Add clue'));
  };
  let title, body;
  if (type === 'source') { title = 'How did it get onto your phone?'; body = h('div', { class: 'opts' }, Object.entries(v.source).map(([k, l]) => pick(l, { type: 'source', value: k, label: l.toLowerCase() }))); }
  if (type === 'kind') { title = 'What was it a photo of?'; body = h('div', { class: 'opts' }, Object.entries(v.kind).map(([k, l]) => pick(l, { type: 'kind', values: [k], label: l.toLowerCase() }))); }
  if (type === 'people') { title = 'Were there people in it?'; body = h('div', { class: 'opts' }, Object.entries(v.people).map(([k, l]) => pick(l, { type: 'people', value: k, label: l.toLowerCase() }))); }
  if (type === 'word') { title = 'A word, name or number that was written in it'; body = textForm('e.g. paracetamol, invoice, Goa', (val) => ({ type: 'word', value: val, label: `“${val}” written in it` })); }
  if (type === 'thing') { title = 'Something that was in it'; body = textForm('e.g. dog, red car, beach', (val) => ({ type: 'thing', terms: [val, val.replace(/s$/, '')], label: val })); }
  if (type === 'when') {
    title = 'Roughly when was it?';
    const years = [...new Set(S.photos.filter((p) => p.date).map((p) => p.date.slice(0, 4)))].sort();
    const now = Date.now();
    body = h('div', { class: 'opts' },
      pick('In the last 3 months', { type: 'when', from: now - 92 * DAY, to: now, label: 'in the last 3 months' }),
      pick('In the last year', { type: 'when', from: now - 366 * DAY, to: now, label: 'in the last year' }),
      years.map((y) => pick(y, { type: 'when', from: Date.parse(`${y}-01-01`), to: Date.parse(`${y}-12-31`) + DAY - 1, label: `in ${y}` })));
  }
  return h('div', { class: 'card question' }, h('h2', {}, title), body, h('div', { style: 'height:10px' }), h('button', { class: 'link small', onclick: onCancel }, 'Cancel'));
}

function openPhoto(row, position, clues) {
  const a = S.attempt, p = row.p, v = S.vocab, dlg = $('#viewer');
  a.photosOpened++;
  const wrong = h('p', { class: 'err', hidden: true }, 'That is not the photo this practice task describes. Keep looking.');
  fill(dlg, h('div', { class: 'view' },
    h('img', { src: p.thumb, alt: p.caption || 'Photo' }),
    h('div', { class: 'body' },
      h('ul', { class: 'facts' },
        p.caption && h('li', {}, p.caption),
        h('li', {}, h('b', {}, 'When: '), p.date ? `${describeWhen(p.date, p.date)} (from ${p.dateFrom || 'the file'})` : 'unknown'),
        h('li', {}, h('b', {}, 'How it arrived: '), v.source[p.source]),
        p.text && h('li', {}, h('b', {}, 'Writing in it: '), p.text.slice(0, 120)),
        row.misses.length > 0 && h('li', { class: 'muted' }, `Does not fit: ${row.misses.map((i) => clues[i].label).join('; ')}`)),
      wrong,
      h('div', { class: 'row' },
        h('button', { class: 'btn good', onclick: () => {
          if (a.practice && a.practice.targetId !== p.id) { a.wrongPicks++; wrong.hidden = false; return; }
          dlg.close(); finishAttempt('found', row, position);
        } }, 'This is the one'),
        h('button', { class: 'btn quiet', onclick: () => { a.dismissed.add(p.id); dlg.close(); render(); } }, 'Not this one'),
        h('button', { class: 'btn quiet', onclick: () => dlg.close() }, 'Back')))));
  dlg.showModal();
}

function viewFind() {
  const a = S.attempt, clues = a.clues;
  const rows = rank(S.photos, clues, a.dismissed);
  const tier0 = rows.filter((r) => r.tier === 0), tier1 = rows.filter((r) => r.tier === 1), tier2 = rows.filter((r) => r.tier === 2);
  const pile = clues.length === 0 ? rows : tier0.length ? tier0 : tier1;
  const q = a.adding ? null : nextQuestion(pile.map((r) => r.p), clues, a.skipped, S.vocab);

  const addClue = (clue, viaQuestion) => {
    const i = clues.findIndex((c) => c.type === clue.type && ['when', 'source', 'kind', 'people', 'setting', 'hastext'].includes(clue.type));
    if (i >= 0) clues.splice(i, 1);
    clues.push(clue); a.adding = null;
    if (viaQuestion) a.questionsAnswered++; else a.cluesAddedByHand++;
    render(); window.scrollTo({ top: 0 });
  };

  const tile = (r, position) => h('button', { class: 'tile', title: r.p.caption || '', onclick: () => openPhoto(r, position, clues) },
    h('img', { src: r.p.thumb, alt: r.p.caption || 'Photo', loading: 'lazy' }),
    r.misses.length > 0 && h('span', { class: 'miss' }, `not ${clues[r.misses[0]].label}`));
  const section = (title, sub, list, offset) => list.length > 0 && [
    h('div', { class: 'tier' }, h('h2', {}, title), h('span', { class: 'muted small' }, sub)),
    h('div', { class: 'grid' }, list.slice(0, 60).map((r, i) => tile(r, offset + i + 1))),
    list.length > 60 && h('p', { class: 'small muted' }, `Showing the first 60 of ${list.length}. Add a clue to shrink this.`)];

  const headline = clues.length === 0
    ? h('span', { class: 'count' }, `${plural(rows.length, 'photo', 'photos')} `, h('span', { class: 'of' }, 'in the library. Add a clue to start narrowing.'))
    : tier0.length
      ? h('span', { class: 'count' }, `${plural(tier0.length, 'photo fits', 'photos fit')} `, h('span', { class: 'of' }, `everything you remember, out of ${S.photos.length.toLocaleString()}`))
      : h('span', { class: 'count' }, 'No photo fits every clue. ', h('span', { class: 'of' }, 'One of them may be misremembered, so here are the closest.'));

  return [
    a.practice && h('div', { class: 'card task' }, h('h2', {}, 'Practice task: find this photo'), h('ul', { style: 'margin:0;padding-left:20px' }, a.practice.lines.map((l) => h('li', {}, l)))),
    a.parseFailed && h('div', { class: 'note' }, 'That sentence could not be split into clues automatically, so it is being matched as plain words. Add clues below to narrow it.'),
    h('div', { class: 'sticky' },
      clues.length > 0 && h('div', { class: 'clues' }, clues.map((c, i) => h('span', { class: 'clue' }, c.label,
        h('button', { 'aria-label': `Remove clue: ${c.label}`, title: 'Remove this clue', onclick: () => { clues.splice(i, 1); a.cluesRemoved++; render(); } }, '×')))),
      headline),

    a.adding ? clueForm(a.adding, (c) => addClue(c, false), () => { a.adding = null; render(); })
      : q ? h('div', { class: 'card question' },
        h('p', { class: 'small muted', style: 'margin-bottom:4px' }, 'One question to narrow it down'),
        h('h2', {}, q.title),
        h('div', { class: 'opts' }, q.options.map((o) => h('button', { class: 'opt', onclick: () => addClue(o.clue, true) }, o.label)),
          h('button', { class: 'opt skip', onclick: () => { a.skipped.add(q.facet); a.questionsSkipped++; render(); } }, 'Not sure')))
        : pile.length <= 12 && clues.length > 0 && h('p', { class: 'muted small' }, 'Few enough to look through.'),

    !a.adding && h('div', { class: 'card' },
      h('p', { class: 'small muted', style: 'margin-bottom:8px' }, 'Add something else you remember'),
      h('div', { class: 'opts' }, [['when', 'Roughly when'], ['source', 'How it arrived'], ['kind', 'What it was'], ['people', 'Who was in it'], ['word', 'A word in it'], ['thing', 'Something in it']]
        .map(([t, l]) => h('button', { class: 'opt', onclick: () => { a.adding = t; render(); } }, l)))),

    clues.length === 0 ? section('All photos', 'newest first', rows, 0)
      : [section('Fits everything you remember', `${tier0.length}`, tier0, 0),
        (tier0.length < 30) && section('Fits all but one clue', 'the label says which', tier1, tier0.length),
        (tier0.length + tier1.length === 0) && section('Closest matches', 'misses two clues', tier2, 0)],

    h('div', { class: 'footbar' },
      h('button', { class: 'btn quiet', onclick: () => { if (confirm('Stop looking for this photo?')) finishAttempt('gave_up', null, null); } }, 'I cannot find it'),
      h('button', { class: 'btn quiet', onclick: () => { S.attempt = null; S.view = 'home'; render(); } }, 'Start over'))
  ];
}

function describeEntry(e) {
  const bits = [`${e.cluesAtEnd.length} clue${e.cluesAtEnd.length === 1 ? '' : 's'}`];
  if (e.questionsAnswered) bits.push(`${e.questionsAnswered} question${e.questionsAnswered === 1 ? '' : 's'} answered`);
  bits.push(`${e.photosOpened} photo${e.photosOpened === 1 ? '' : 's'} opened`);
  return bits.join(', ');
}

function viewDone() {
  const e = S.log[0];
  const note = h('textarea', { placeholder: 'Optional: what helped, or what got in the way?', style: 'min-height:70px' });
  note.addEventListener('change', () => { e.note = note.value.trim().slice(0, 400); saveLog(); });
  return [
    h('div', { class: 'card result' },
      e.outcome === 'found'
        ? [h('p', { class: 'muted' }, 'Found it'), h('p', { class: 'big' }, `${e.seconds} seconds`),
          h('p', {}, `${describeEntry(e)}. It was number ${e.foundPosition} in the list${e.foundTier ? ', among photos that missed one clue' : ''}.`)]
        : [h('p', { class: 'muted' }, 'Not found'), h('p', { class: 'big' }, `Stopped after ${e.seconds} seconds`), h('p', {}, `${describeEntry(e)}.`)],
      note),
    h('div', { class: 'row' },
      h('button', { class: 'btn', onclick: () => { S.view = 'home'; render(); } }, 'Find another photo'),
      h('button', { class: 'btn ghost', onclick: () => { S.view = 'log'; render(); } }, 'See test results'))
  ];
}

function logText() {
  const found = S.log.filter((e) => e.outcome === 'found');
  const med = (arr) => { if (!arr.length) return '-'; const s = [...arr].sort((x, y) => x - y); return s[Math.floor((s.length - 1) / 2)]; };
  const lines = [`Clue finder test results (${S.log.length} attempts)`,
    `Found: ${found.length} of ${S.log.length}. Median seconds to find: ${med(found.map((e) => e.seconds))}. Found in the top 12: ${found.filter((e) => e.foundPosition <= 12).length}.`, ''];
  S.log.forEach((e, i) => lines.push(
    `${i + 1}. ${e.outcome === 'found' ? 'FOUND' : 'NOT FOUND'} in ${e.seconds}s | library ${e.library}${e.sample ? ' (sample)' : ''}${e.practice ? ' | practice task' : ''}`,
    `   memory: ${e.memory || '(started from clues)'}`,
    `   clues at end: ${e.cluesAtEnd.join(', ') || 'none'} | from sentence: ${e.cluesFromSentence}${e.parseFailed ? ' (sentence not understood)' : ''} | added by hand: ${e.cluesAddedByHand} | removed: ${e.cluesRemoved}`,
    `   questions answered: ${e.questionsAnswered}, skipped: ${e.questionsSkipped} | photos opened: ${e.photosOpened}${e.practice ? ` | wrong picks: ${e.wrongPicks}` : ''}`,
    `   position in list: ${e.foundPosition ?? '-'}${e.foundTier ? ' (missed one clue)' : ''}${e.note ? `\n   note: ${e.note}` : ''}`));
  return lines.join('\n');
}

function viewLog() {
  const found = S.log.filter((e) => e.outcome === 'found');
  const status = h('span', { class: 'small muted', role: 'status' });
  return [
    h('h1', {}, 'Test results'),
    h('p', { class: 'muted' }, 'Every attempt on this device. Copy these and send them to whoever is running the test.'),
    h('div', { class: 'card' }, h('p', { class: 'big' }, `${found.length} of ${S.log.length} found`),
      h('div', { class: 'scroll' }, h('table', {},
        h('thead', {}, h('tr', {}, ['Result', 'Seconds', 'Clues', 'Questions', 'Opened', 'Position', 'What they remembered'].map((t) => h('th', {}, t)))),
        h('tbody', {}, S.log.map((e) => h('tr', {},
          h('td', {}, e.outcome === 'found' ? 'Found' : 'Not found'), h('td', {}, e.seconds), h('td', {}, e.cluesAtEnd.length),
          h('td', {}, `${e.questionsAnswered} of ${e.questionsAnswered + e.questionsSkipped}`), h('td', {}, e.photosOpened), h('td', {}, e.foundPosition ?? ''),
          h('td', {}, e.practice ? 'Practice task' : e.memory || 'Started from clues'))))))),
    h('div', { class: 'row' },
      h('button', { class: 'btn', onclick: async () => {
        const text = logText();
        try { await navigator.clipboard.writeText(text); status.textContent = 'Copied.'; }
        catch { const t = h('textarea', {}, text); document.body.append(t); t.select(); document.execCommand('copy'); t.remove(); status.textContent = 'Copied.'; }
      } }, 'Copy results'),
      h('button', { class: 'btn ghost', onclick: () => { S.view = 'home'; render(); } }, 'Back'),
      h('button', { class: 'btn quiet', onclick: () => { if (confirm('Delete all test results on this device?')) { S.log = []; saveLog(); S.view = 'home'; render(); } } }, 'Clear results'),
      status)
  ];
}

function render() {
  const app = $('#app');
  if (S.view === 'home' && !S.photos.length) S.view = 'setup';
  fill(app, { setup: viewSetup, home: viewHome, find: viewFind, done: viewDone, log: viewLog }[S.view]?.() || h('p', { class: 'muted' }, 'Loading…'));
}

async function loadSample() {
  const resp = await fetch('/sample-library.json', { cache: 'no-store' });
  const d = await resp.json();
  S.photos = d.photos; S.isSample = true;
}

async function init() {
  try { S.status = await api('/api/status'); S.vocab = S.status.vocab; }
  catch { banner('The server did not respond. Reload the page.', true); return; }
  try { S.log = JSON.parse(localStorage.getItem(LOG_KEY) || '[]'); } catch { S.log = []; }
  try { const resp = await fetch('/sample-library.json', { cache: 'no-store' }); const d = resp.ok ? await resp.json() : null; S.hasSample = Array.isArray(d?.photos) && d.photos.length > 0; } catch { S.hasSample = false; }
  try { const saved = await db.get('library'); if (saved?.photos?.length) { S.photos = saved.photos; S.isSample = !!saved.isSample; } } catch { /* nothing saved */ }
  if (!S.photos.length && S.hasSample) await loadSample();
  if (S.status.mock) banner('Mock mode: photo descriptions are made up by test rules, not a model.', true);
  S.view = S.photos.length ? 'home' : 'setup';
  render();
}

init();
