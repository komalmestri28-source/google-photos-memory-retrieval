# Clue finder (MVP)

A prototype for finding a photo you remember only vaguely. Instead of one search
box, you give whatever fragments you have (roughly when, how it reached your
phone, what it was, a word in it) and the pile shrinks as the clues stack up.

What it does differently from a search box:

1. **Splits a sentence into clues of known kinds.** "The medicine from last
   winter, came on WhatsApp" becomes three separate clues: a kind, a time range
   and a source.
2. **Never returns nothing.** A photo that misses one clue drops to a second
   group labelled with the clue it misses, so one wrong memory cannot hide it.
3. **Asks one question when the pile is still big,** choosing the question whose
   answer splits the remaining photos most evenly.

The model is used in two places only: describing each photo once when a library
is added, and splitting the sentence into clues. Narrowing runs in the browser
with no model calls, so it is instant and does not spend quota.

## Run it

Needs Node 20 or newer. There are no packages to install.

```bash
cp .env.example .env      # paste ONE key into .env
npm run dev               # http://localhost:3000
npm test                  # checks the logic in mock mode, no key needed
```

## Make the sample library (so the public link is not empty)

1. Run it locally and choose "Add your own photos". Pick 60 to 100 photos you are
   happy for anyone to see: a mix of camera shots, screenshots, WhatsApp images,
   bills, documents, food, places.
2. When it finishes, press "Export library" and save the file over
   `public/sample-library.json`.
3. Deploy. Visitors land straight in the finder with that library and can try a
   practice task without uploading anything.

Describing 100 photos takes about 20 model requests. Each typed sentence takes one.

## Deploy to Vercel

Same as the discovery engine: push to GitHub, import in Vercel with the "Other"
preset, add `GEMINI_API_KEY` (or `ANTHROPIC_API_KEY`) as an environment variable,
deploy. If the default model is refused, set `LLM_MODEL`.

## Running a user test

1. The tester opens the link on their own phone and adds 50 to 150 of their own
   photos. Tell them first: a shrunken copy of each photo is sent once to the
   model provider to be described, so they should leave out anything sensitive.
2. Ask them to think of a photo in that set that they remember only loosely, and
   to find it. Do not help. Repeat with a second photo of a different kind.
3. Afterwards: "Test results" > "Copy results", and have them send you the text.
   It records time, clues used, questions answered, photos opened and where the
   photo sat in the list.

## Limits of this prototype

- It knows how many people are in a photo, not who they are. In the real product
  the "who" clue would come from Google Photos' existing face groups.
- "How it arrived" is read from the file name and camera data, which some phones
  strip when a photo is uploaded through the browser.
- It searches only the photos added to it, not a real Google Photos library.
