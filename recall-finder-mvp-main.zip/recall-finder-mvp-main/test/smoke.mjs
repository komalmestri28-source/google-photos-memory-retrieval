// Checks the matching logic and the API handlers in mock mode. No network, no key.
import assert from 'node:assert/strict';
import http from 'node:http';
import { DAY, detectSource, dateFromName, clueScore, rank, nextQuestion, practiceTask } from '../public/engine.js';
import { VOCAB, sanitizeClues } from '../lib/vocab.js';

// --- file-name facts ---
assert.equal(detectSource('Screenshot_2024-03-15-10-22-01.png', false, false), 'screenshot');
assert.equal(detectSource('IMG-20240315-WA0007.jpg', false, false), 'whatsapp');
assert.equal(detectSource('IMG_20240315_101500.jpg', false, false), 'camera');
assert.equal(detectSource('photo.jpg', true, false), 'camera');
assert.equal(detectSource('image.png', false, true), 'screenshot');
assert.equal(detectSource('download (3).jpg', false, false), 'saved');
assert.equal(dateFromName('IMG-20240315-WA0007.jpg'), '2024-03-15');
assert.equal(dateFromName('Screenshot_2023-11-02-09-00-00.png'), '2023-11-02');
assert.equal(dateFromName('holiday.jpg'), null);
assert.equal(dateFromName('IMG_20991340.jpg'), null);

// --- a small made-up library ---
const mk = (id, o) => ({ id, described: true, caption: '', tags: [], text: '', kind: 'other', people: 'none', setting: 'unknown', source: 'camera', date: null, ...o });
const lib = [
  mk('a', { kind: 'medical', source: 'whatsapp', date: '2025-01-10', caption: 'A blue strip of tablets on a table', tags: ['medicine', 'tablet', 'strip'], text: 'Paracetamol 650' }),
  mk('b', { kind: 'medical', source: 'camera', date: '2025-01-20', caption: 'A bottle of cough syrup', tags: ['medicine', 'syrup', 'bottle'], text: 'Cough Syrup' }),
  mk('c', { kind: 'receipt', source: 'camera', date: '2024-06-02', caption: 'A paper bill', tags: ['bill', 'receipt'], text: 'Total 4,599' }),
  mk('d', { kind: 'place', source: 'camera', date: '2023-12-28', caption: 'A cafe by the beach', tags: ['cafe', 'beach', 'goa'], people: 'two', setting: 'outdoor' }),
  mk('e', { kind: 'chat', source: 'screenshot', date: '2025-02-15', caption: 'A chat about dinner', tags: ['chat', 'message'], text: 'Dinner at 8?', setting: 'screen' })
];
const when = (from, to) => ({ type: 'when', from: Date.parse(from), to: Date.parse(to) + DAY - 1, label: 'then' });

assert.equal(clueScore(when('2025-01-01', '2025-01-31'), lib[0]), 1);
assert.equal(clueScore(when('2024-11-01', '2024-12-31'), lib[0]), 0.5, 'just outside the range is a near miss, not a miss');
assert.equal(clueScore(when('2023-01-01', '2023-03-31'), lib[0]), 0);
assert.equal(clueScore(when('2023-01-01', '2023-03-31'), mk('x', {})), 0.5, 'an undated photo cannot be ruled out');
assert.equal(clueScore({ type: 'word', value: 'paracetamol' }, lib[0]), 1);
assert.equal(clueScore({ type: 'word', value: 'syrup' }, lib[0]), 0);
assert.equal(clueScore({ type: 'thing', terms: ['pill', 'tablet'] }, lib[0]), 1);
assert.equal(clueScore({ type: 'thing', terms: ['cat'] }, mk('y', { caption: 'A vacation photo' })), 0, 'matches whole words, not fragments');
assert.equal(clueScore({ type: 'people', value: 'group' }, lib[3]), 0.5);

// Three clues that each match many photos single out one when stacked.
let clues = [{ type: 'kind', values: ['medical'], label: 'medicine' }, { type: 'source', value: 'whatsapp', label: 'whatsapp' }, when('2024-12-01', '2025-02-28')];
let rows = rank(lib, clues);
assert.equal(rows[0].p.id, 'a'); assert.equal(rows[0].tier, 0);
assert.equal(rows.filter((r) => r.tier === 0).length, 1);
assert.equal(rows[1].p.id, 'b'); assert.deepEqual(rows[1].misses, [1], 'the near match reports which clue it misses');
assert.equal(rows.length, lib.length, 'nothing is filtered out');

// A wrong clue does not produce an empty result.
clues = [{ type: 'kind', values: ['medical'], label: 'medicine' }, { type: 'source', value: 'screenshot', label: 'a screenshot' }, { type: 'word', value: 'paracetamol', label: 'word' }];
rows = rank(lib, clues);
assert.equal(rows.filter((r) => r.tier === 0).length, 0);
assert.equal(rows[0].p.id, 'a'); assert.deepEqual(rows[0].misses, [1]);
assert.equal(rank(lib, clues, new Set(['a']))[0].p.id !== 'a', true, 'dismissed photos leave the list');

// --- next question ---
const big = [];
for (let i = 0; i < 40; i++) big.push(mk('p' + i, { kind: i % 2 ? 'receipt' : 'people', source: ['camera', 'screenshot', 'whatsapp', 'saved'][i % 4], date: `202${3 + (i % 3)}-0${1 + (i % 9)}-10`, text: i % 5 ? '' : 'x' }));
let q = nextQuestion(big, [], new Set(), VOCAB);
assert.equal(q.facet, 'source', 'asks the question that splits the pile most evenly'); assert.equal(q.options.length, 4);
q = nextQuestion(big, [{ type: 'source', value: 'camera' }], new Set(), VOCAB);
assert.equal(q.facet, 'when'); assert.deepEqual(q.options.map((o) => o.label), ['2023', '2024', '2025']);
q = nextQuestion(big, [{ type: 'source' }, { type: 'when' }], new Set(['kind']), VOCAB);
assert.notEqual(q?.facet, 'kind', 'a skipped question is not asked again');
assert.equal(nextQuestion(big.slice(0, 12), [], new Set(), VOCAB), null, 'a small pile gets no question');
assert.equal(nextQuestion(big.map((p) => ({ ...p, source: 'camera', kind: 'people', date: '2024-01-01', text: '', people: 'none' })), [], new Set(), VOCAB), null, 'no question when nothing would narrow');

// --- practice task ---
const t = practiceTask(lib, VOCAB, () => 0);
assert.equal(t.targetId, 'a'); assert.ok(t.lines.join(' ').includes('WhatsApp')); assert.ok(!t.lines.join(' ').includes('Paracetamol'));
assert.equal(practiceTask([mk('z', { described: false })], VOCAB), null);

// --- clue sanitising ---
const sc = sanitizeClues({ when: { from: '2024-01-01', to: '2024-12-31', label: 'last year' }, source: 'email', kind: ['medical', 'nope'], people: 'two', words: ['Paracetamol'], things: [{ label: 'medicine', terms: ['Medicine', 'tablet'] }] });
assert.equal(sc.source, null); assert.deepEqual(sc.kind, ['medical']); assert.deepEqual(sc.words, ['paracetamol']); assert.equal(sc.when.label, 'last year');

// --- endpoints ---
process.env.MOCK_LLM = '1';
const handlers = {};
for (const name of ['status', 'index-photos', 'parse']) handlers[name] = (await import(`../api/${name}.js`)).default;
const server = http.createServer((req, res) => handlers[req.url.split('/').pop()](req, res)).listen(0);
const base = `http://localhost:${server.address().port}/api/`;
const post = async (p, body) => { const r = await fetch(base + p, { method: 'POST', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } }); return { status: r.status, json: await r.json() }; };

assert.equal((await (await fetch(base + 'status')).json()).mock, true);
let r = await post('index-photos', { photos: [{ id: 'p1', image: 'data:image/jpeg;base64,AAAA' }, { id: 'p2', image: 'BBBB' }] });
assert.equal(r.status, 200); assert.equal(r.json.photos.length, 2); assert.equal(r.json.photos[0].described, true); assert.equal(r.json.photos[0].extra, undefined);
assert.equal((await post('index-photos', { photos: [] })).status, 400);
assert.equal((await post('index-photos', { photos: Array.from({ length: 6 }, (_, i) => ({ id: 'p' + i, image: 'AAAA' })) })).status, 400);
assert.equal((await post('index-photos', { photos: [{ id: 'p1', image: '<script>' }] })).status, 400);
r = await post('parse', { memory: 'the medicine photo from last year, came on whatsapp', today: '2026-10-06' });
assert.equal(r.status, 200); assert.equal(r.json.clues.source, 'whatsapp'); assert.equal(r.json.clues.when.from, '2025-01-01'); assert.deepEqual(r.json.clues.kind, ['medical']);
assert.equal((await post('parse', { memory: 'a' })).status, 400);

delete process.env.MOCK_LLM; delete process.env.GEMINI_API_KEY; delete process.env.ANTHROPIC_API_KEY;
r = await post('parse', { memory: 'something from last year' });
assert.equal(r.status, 500); assert.match(r.json.error, /No API key/);
server.close();
console.log('All checks passed.');
